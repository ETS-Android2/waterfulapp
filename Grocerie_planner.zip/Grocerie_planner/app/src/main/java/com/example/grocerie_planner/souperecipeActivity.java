package com.example.grocerie_planner;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class souperecipeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_souperecipe);
    }
}